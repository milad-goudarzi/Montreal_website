
export default {
    methods: {
        formatMyDate(val){
            return "Date: " + val
        }
    }
}