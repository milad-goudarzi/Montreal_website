<template>
  <div class="main-page">
    <nuxt />
  </div>
</template>

<script>
export default {
  name: 'EmptyLayout',
}
</script>